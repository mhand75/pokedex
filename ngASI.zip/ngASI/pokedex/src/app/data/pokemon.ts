export enum Type {
    BUG, DRAGON, FAIRY, FIRE, GHOST, GROUND, NORMAL, PSYCHIC, STEEL,
    DARK, ELECTRIC, FIGHTING, FLYING, GRASS, ICE, POISON, ROCK, WATER
}

export class Pokemon {
    id: number;
    name: string;
    description: string;
    type: Type[];
    img: string;
}

export const PokemonList: Pokemon[] = [
    {
        id: 1,
        name: 'Bulbasaur',
        description: "Bulbasaur can be seen napping in bright sunlight. There is a seed on its back. By soaking up the sun's rays, the seed grows progressively larger.",
        type: [Type.GRASS, Type.POISON],
        img: '1.png'
    },
    {
        id: 2,
        name: 'Ivysaur',
        description: "There is a bud on this Pokémon's back. To support its weight, Ivysaur's legs and trunk grow thick and strong. If it starts spending more time lying in the sunlight, it's a sign that the bud will bloom into a large flower soon.",
        type: [Type.GRASS, Type.POISON],
        img: '2.png'
    },
    {
        id: 3,
        name: 'Venusaur',
        description: "There is a large flower on Venusaur's back. The flower is said to take on vivid colors if it gets plenty of nutrition and sunlight. The flower's aroma soothes the emotions of people.",
        type: [Type.GRASS, Type.POISON],
        img: '3.png'
    },
    {
        id: 4,
        name: 'Charmander',
        description: "The flame that burns at the tip of its tail is an indication of its emotions. The flame wavers when Charmander is enjoying itself. If the Pokémon becomes enraged, the flame burns fiercely.",
        type: [Type.FIRE],
        img: '4.png'
    },
    {
        id: 5,
        name: 'Charmeleon',
        description: "Charmeleon mercilessly destroys its foes using its sharp claws. If it encounters a strong foe, it turns aggressive. In this excited state, the flame at the tip of its tail flares with a bluish white color.",
        type: [Type.FIRE],
        img: '5.png'
    },
    {
        id: 6,
        name: 'Charizard',
        description: "Charizard flies around the sky in search of powerful opponents. It breathes fire of such great heat that it melts anything. However, it never turns its fiery breath on any opponent weaker than itself.",
        type: [Type.FIRE, Type.FLYING],
        img: '6.png'
    },
    {
        id: 7,
        name: 'Squirtle',
        description: "Squirtle's shell is not merely used for protection. The shell's rounded shape and the grooves on its surface help minimize resistance in water, enabling this Pokémon to swim at high speeds.",
        type: [Type.WATER],
        img: '7.png'
    },
    {
        id: 8,
        name: 'Wartortle',
        description: "Its tail is large and covered with a rich, thick fur. The tail becomes increasingly deeper in color as Wartortle ages. The scratches on its shell are evidence of this Pokémon's toughness as a battler.",
        type: [Type.WATER],
        img: '8.png'
    },
    {
        id: 9,
        name: 'Blastoise',
        description: "Blastoise has water spouts that protrude from its shell. The water spouts are very accurate. They can shoot bullets of water with enough accuracy to strike empty cans from a distance of over 16 feet.",
        type: [Type.WATER],
        img: '9.png'
    },
    {
        id: 25,
        name: 'Pikachu',
        description: "Whenever Pikachu comes across something new, it blasts it with a jolt of electricity. If you come across a blackened berry, it's evidence that this Pokémon mistook the intensity of its charge.",
        type: [Type.ELECTRIC],
        img: '25.png'
    },
    {
        id: 26,
        name: 'Raichu',
        description: "If the electrical sacs become excessively charged, Raichu plants its tail in the ground and discharges. Scorched patches of ground will be found near this Pokémon's nest.",
        type: [Type.ELECTRIC],
        img: '26.png'
    },
    {
        id: 133,
        name: 'Eevee',
        description: "Eevee has an unstable genetic makeup that suddenly mutates due to the environment in which it lives. Radiation from various stones causes this Pokémon to evolve.",
        type: [Type.NORMAL],
        img: '133.png'
    },
    {
        id: 134,
        name: 'Vaporeon',
        description: "Vaporeon underwent a spontaneous mutation and grew fins and gills that allow it to live underwater. This Pokémon has the ability to freely control water.",
        type: [Type.WATER],
        img: '134.png'
    },
    {
        id: 135,
        name: 'Jolteon',
        description: "Jolteon's cells generate a low level of electricity. This power is amplified by the static electricity of its fur, enabling the Pokémon to drop thunderbolts. The bristling fur is made of electrically charged needles.",
        type: [Type.ELECTRIC],
        img: '135.png'
    },
    {
        id: 136,
        name: 'Flareon',
        description: "Flareon's fluffy fur has a functional purpose—it releases heat into the air so that its body does not get excessively hot. This Pokémon's body temperature can rise to a maximum of 1,65 degrees Fahrenheit.",
        type: [Type.FIRE],
        img: '136.png'
    },
    
]
