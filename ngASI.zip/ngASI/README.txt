
Angular requires Node.js version 8.x or 10.x.
-To check your version, run node -v in a terminal/console window.
-To get Node.js, go to nodejs.org.

Angular features depend on npm packages. To download and install npm packages, you must have an npm package manager.
-npm client CLI is installed with Node.js by default
-To check that you have the npm client installed, run npm -v in a terminal/console window.

To begin, enter pokedex/ from the commandline, run
>npm install
ng serve